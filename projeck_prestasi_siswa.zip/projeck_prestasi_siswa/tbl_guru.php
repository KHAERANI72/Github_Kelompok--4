<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

$query_group = "SELECT bidang, COUNT(*) AS jumlah_guru 
                FROM guru_pembimbing 
                GROUP BY bidang 
                HAVING COUNT(*) > 1";
$result_group = mysqli_query($koneksi, $query_group);

$query_all = "SELECT * FROM guru_pembimbing";
$result_all = mysqli_query($koneksi, $query_all);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Data Guru</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Sistem Guru</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tbl_siswa.php">Data Siswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="prestasi.php">Prestasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="tbl_guru.php">Guru</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="rigkas_prestasi.php">Rekap Prestasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container mt-4">
    <h2 class="text-center">Data Guru</h2>
    <a href="tambah_guru.php" class="btn btn-primary mb-3">✅ Tambah Data</a>
    
    <h3>📌 Jumlah Guru Per Bidang (Bidang dengan lebih dari 1 guru)</h3>
    <table class="table table-bordered">
        <tr>
            <th>Bidang</th>
            <th>Jumlah Guru</th>
        </tr>
        <?php while ($data = mysqli_fetch_assoc($result_group)) { ?>
        <tr>
            <td><?= $data['bidang']; ?></td>
            <td><?= $data['jumlah_guru']; ?></td>
        </tr>
        <?php } ?>
    </table>

    <h3>📰 Data Lengkap Guru</h3>
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Bidang</th>
            <th>No HP</th>
            <th>Email</th>
            <th>Alamat</th>
            <th>Mata Pelajaran</th>
            <th>Tindakan</th>
        </tr>
        <?php while ($data = mysqli_fetch_assoc($result_all)) { ?>
        <tr>
            <td><?php echo $data['id_guru']; ?></td>
            <td><?php echo $data['nama_guru']; ?></td>
            <td><?php echo $data['bidang']; ?></td>
            <td><?php echo $data['no_telpon']; ?></td>
            <td><?php echo $data['email']; ?></td>
            <td><?php echo $data['alamat']; ?></td>
            <td><?php echo $data['mata_pelajaran']; ?></td>
            <td>
                <a href="edit_guru.php?id=<?= $data['id_guru']; ?>" class="btn btn-warning btn-sm"> ✏️ Edit</a>
                <a href="hapus_guru.php?id=<?= $data['id_guru']; ?>" class="btn btn-danger btn-sm" 
                onclick="return confirm('Apakah anda yakin ingin mengahapus data ini?')"> 📛 Hapus</a>
            </td>
        </tr>
        <?php } ?>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
