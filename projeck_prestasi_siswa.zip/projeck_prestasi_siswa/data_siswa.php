<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Query utama (menampilkan semua data siswa)
$result = mysqli_query($koneksi, "SELECT * FROM siswaa");
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Data Siswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Sistem Siswa</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link " href="index_guru.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="data_siswa.php">Data Siswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="data_prestasi.php">Prestasi</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container mt-4">
    <h2 class="text-center"> 📰 Data Siswa</h2>
    <a href="tambah_siswa.php" class="btn btn-primary mb-3"> ✅ Tambah Data</a>
    
    <table class="table table-bordered">
        <tr>
            <th>ID</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Jurusan</th>
            <th>Jenis Kelamin</th>
            <th>Saldo</th>
            <th>Alamat</th> 
            <th>Keahlian</th>
            <th>Aksi</th>   
        </tr>
        <?php
           $i = 1;
           while ($data = mysqli_fetch_array($result)) {
        ?>
        <tr>
            <td><?php echo $i; ?></td>
            <td><?php echo $data['nama_siswa']; ?></td>
            <td><?php echo $data['kelas']; ?></td>
            <td><?php echo $data['jurusan']; ?></td>
            <td><?php echo $data['jenis_kelamin']; ?></td>
            <td><?php echo $data['saldo']; ?></td>
            <td><?php echo $data['alamat']; ?></td>
            <td><?php echo $data['keahlian']; ?></td>
        </tr>
        <?php
           $i++;
            }
        ?>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
