<?php
include "koneksi.php";
$id = $_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM siswaa WHERE id_siswa='$id'");
header('Location:tbl_siswa.php');

?>

