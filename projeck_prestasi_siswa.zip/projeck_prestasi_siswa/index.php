<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

// Menghitung jumlah data di masing-masing tabel
$jumlah_siswa = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM siswaa"))['total'];
$jumlah_guru = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM guru_pembimbing"))['total'];
$jumlah_prestasi = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) AS total FROM detail_prestasi"))['total'];

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Sistem Prestasi</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item"><a class="nav-link active" href="index.php">Home</a></li>
                <li class="nav-item"><a class="nav-link" href="tbl_siswa.php">Data Siswa</a></li>
                <li class="nav-item"><a class="nav-link" href="prestasi.php">Prestasi</a></li>
                <li class="nav-item"><a class="nav-link" href="tbl_guru.php">Guru</a></li>
                <li class="nav-item"><a class="nav-link" href="rigkas_prestasi.php">Rekap Prestasi</a></li>
                <li class="nav-item"><a class="nav-link btn btn-danger text-white" href="logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<!-- Konten -->
<div class="container mt-4">
    <h2 class="text-center">📌 Selamat Datang, <?= $_SESSION['username']; ?>!</h2>
    <p class="text-center">Silakan gunakan menu di atas untuk mengelola data .</p>

    <!-- Statistik Data -->
    <div class="row text-center mt-4">
        <div class="col-md-4">
            <div class="card bg-primary text-white p-3">
                <h4>Jumlah Siswa</h4>
                <h3><?= $jumlah_siswa; ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-success text-white p-3">
                <h4>Jumlah Guru</h4>
                <h3><?= $jumlah_guru; ?></h3>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card bg-warning text-white p-3">
                <h4>Jumlah Prestasi</h4>
                <h3><?= $jumlah_prestasi; ?></h3>
            </div>
        </div>
    </div>

    <!-- Prestasi Terbaru -->
    <h3 class="text-center mt-4">🏆 Prestasi Terbaru</h3>
    <table class="table table-bordered mt-3">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Prestasi</th>
                <th>Juara</th>
                <th>Tingkat</th>
                <th>Tahun</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            $query = "SELECT p.nama_prestasi, dp.peringkat, p.tingkat, YEAR(dp.tanggal_prestasi) AS tahun
                      FROM detail_prestasi dp
                      JOIN prestasi p ON dp.id_prestasi = p.id_prestasi
                      ORDER BY dp.tanggal_prestasi DESC
                      LIMIT 5";
            $result = mysqli_query($koneksi, $query);

            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>{$no}</td>
                        <td>{$row['nama_prestasi']}</td>
                        <td>Juara {$row['peringkat']}</td>
                        <td>{$row['tingkat']}</td>
                        <td>{$row['tahun']}</td>
                      </tr>";
                $no++;
            }
            ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>