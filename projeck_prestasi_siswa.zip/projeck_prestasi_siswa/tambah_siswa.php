<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['tambah'])) {
    $id_siswa = $_POST['id_siswa'];
    $nama_siswa = $_POST['nama_siswa'];
    $kelas = $_POST['kelas'];
    $jurusan = $_POST['jurusan'];
    $jenis_kelamin = $_POST['jenis_kelamin'];
    $saldo = $_POST['saldo'];
    $alamat = $_POST['alamat'];
    $keahlian = $_POST['keahlian'];

    $query = "INSERT INTO siswaa (id_siswa, nama_siswa, kelas, jurusan, jenis_kelamin, saldo, alamat, keahlian) 
              VALUES ('$id_siswa','$nama_siswa', '$kelas', '$jurusan', '$jenis_kelamin', '$saldo', '$alamat', '$keahlian')";

    if (mysqli_query($koneksi, $query)) {
        echo "Data berhasil ditambahkan!";
        header('Location: tbl_siswa.php');
            exit();
    } else {
        echo "Gagal menambahkan data: " . mysqli_error($koneksi);
    }
}
?>
<link rel="stylesheet" href="form.css">
<div class="container">
<form method="POST" action="">
    <label for="id_siswa">Id Siswa:</label>
    <input type="text" name="id_siswa" required>

    <label for="nama_siswa">Nama:</label>
    <input type="text" name="nama_siswa" required>

    <label for="kelas">Kelas:</label>
    <input type="text" name="kelas" required>

    <label for="jurusan">Jurusan:</label>
    <input type="text" name="jurusan" required><br>
    
    <label for="jenis_kelamin">Jenis Kelamin: </label>
    <select name="jenis_kelamin">
        <option value="Laki-laki">Laki-laki</option>
        <option value="Perempuan">Perempuan</option>
    </select>
    <script>
function formatRupiah(input) {
    let value = input.value.replace(/[^0-9]/g, ""); // Hanya angka
    input.value = value ? "Rp " + parseInt(value).toLocaleString("id-ID") : "";
}
</script>

<label for="saldo">Saldo:</label>
<input type="text" name="saldo_display" oninput="formatRupiah(this)" required>
<input type="hidden" name="saldo"> <!-- Menyimpan angka asli -->


    <label for="jurusan">Alamat:</label>
    <input type="text" name="alamat" required><br>
    
    <label for="jurusan">Keahlian:</label>
     <input type="text" name="keahlian" required><br>
    
    <button type="submit" name="tambah">Tambah</button>
    <script>
document.querySelector("form").addEventListener("submit", function() {
    let saldoDisplay = document.querySelector("[name='saldo_display']").value;
    document.querySelector("[name='saldo']").value = saldoDisplay.replace(/\D/g, ""); // Hanya angka
});
</script>

    <button type="button" onclick="window.history.back();">Kembali</button>
    <button type="reset">Batal</button>
</form>

</div>
