<?php include 'koneksi.php'; ?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filter Prestasi Siswa</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h2 { text-align: center; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table, th, td { border: 1px solid black; text-align: center; }
        th, td { padding: 10px; }
        .filter-container { display: flex; gap: 10px; margin-bottom: 10px; }
    </style>
</head>
<body>

    <h2>Filter Prestasi Siswa</h2>

    <!-- Form Filter -->
    <form method="post" action="">
        <div class="filter-container">
            <input type="text" name="nama" placeholder="Cari Nama Siswa" value="<?= isset($_POST['nama']) ? $_POST['nama'] : '' ?>">
            <select name="tingkat">
                <option value="">Pilih Tingkat</option>
                <option value="Sekolah" <?= isset($_POST['tingkat']) && $_POST['tingkat'] == "Sekolah" ? "selected" : "" ?>>Sekolah</option>
                <option value="Kota" <?= isset($_POST['tingkat']) && $_POST['tingkat'] == "Kota" ? "selected" : "" ?>>Kota</option>
                <option value="Provinsi" <?= isset($_POST['tingkat']) && $_POST['tingkat'] == "Provinsi" ? "selected" : "" ?>>Provinsi</option>
                <option value="Nasional" <?= isset($_POST['tingkat']) && $_POST['tingkat'] == "Nasional" ? "selected" : "" ?>>Nasional</option>
                <option value="Internasional" <?= isset($_GPOST['tingkat']) && $_POST['tingkat'] == "Internasional" ? "selected" : "" ?>>Internasional</option>
            </select>
            <input type="date" name="tanggal_prestasi" placeholder="Tanggal_prestasi" value="<?= isset($_POST['tanggal_prestasi']) ? $_POST['tanggal_prestasi'] : '' ?>">
            <button type="submit">Filter</button>
        </div>
    </form>

    <!-- Tabel Daftar Prestasi -->
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>Prestasi</th>
                <th>Tingkat</th>
                <th>Tanggal_prestasi</th>
                <th>Guru Pembimbing</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Query dasar
            $query = "SELECT dp.id_detailprestasi, s.nama_siswa AS nama_siswa, p.nama_prestasi, t.tingkatan, g.nama_guru AS nama_guru, dp.tanggal_prestasi
                      FROM detail_prestasi dp
                      INNER JOIN siswaa s ON dp.id_siswa = s.id_siswa
                      INNER JOIN prestasi p ON dp.id_prestasi = p.id_prestasi
                      INNER JOIN tingkat t ON p.tingkatan = t.tingkatan
                      INNER JOIN guru_pembimbing g ON dp.id_guru = g.id_guru
                      WHERE 1=1";

            // Filter berdasarkan input pengguna
            if (isset($_POST['nama_siswa']) && $_POST['nama_siswa'] != "") {
                $nama_siswa = $_POST['nama_siswa'];
                $query .= " AND s.nama_siswa LIKE '%$nama%'";
            }
            if (isset($_POST['tingkat']) && $_POST['tingkat'] != "") {
                $tingkatan = $_POST['tingkat'];
                $query .= " AND t.tingkatan = '$tingkatan'";
            }
            if (isset($_POST['tanggal_prestasi']) && $_POST['tanggal_prestasi'] != "") {
                $tanggal_prestasi = $_POST['tanggal_prestasi'];
                $query .= " AND dp.tanggal_prestasi = '$tanggal_prestasi'";
            }

            $result = $koneksi->query($query);
            if (!$result) {
                die("Query Error: " . $koneksi->error);
            }            
            $no = 1;
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>".$no++."</td>
                        <td>".$row['nama_siswa']."</td>
                        <td>".$row['nama_prestasi']."</td>
                        <td>".$row['tingkatan']."</td>
                        <td>".$row['tanggal_prestasi']."</td>
                        <td>".$row['nama_guru']."</td>
                      </tr>";
            }
            ?>
        </tbody>
    </table>

</body>
</html>
