<?php
include "koneksi.php"; // Pastikan koneksi ke database

// Ambil jumlah prestasi berdasarkan tingkat
$query_tingkat = "SELECT p.tingkatan, COUNT(dp.id_prestasi) AS jumlah 
                   FROM prestasi p
                   JOIN detail_prestasi dp ON p.id_prestasi = dp.id_prestasi
                   GROUP BY p.tingkatan";
$result_tingkat = mysqli_query($koneksi, $query_tingkat);

// Ambil siswa dengan prestasi terbanyak
$query_top_siswa = "SELECT s.nama_siswa, COUNT(dp.id_prestasi) AS jumlah 
                    FROM siswaa s
                    JOIN detail_prestasi dp ON s.id_siswa = dp.id_siswa
                    GROUP BY s.nama_siswa
                    ORDER BY jumlah DESC
                    LIMIT 1";
$result_top_siswa = mysqli_query($koneksi, $query_top_siswa);
$top_siswa = mysqli_fetch_assoc($result_top_siswa);

// Ambil daftar prestasi terbaru dengan guru pembimbing
$query_recent = "SELECT s.nama_siswa AS nama_siswa, p.nama_prestasi, p.tingkatan, dp.tanggal_prestasi, g.nama_guru 
                 FROM detail_prestasi dp
                 JOIN siswaa s ON dp.id_siswa = s.id_siswa
                 JOIN prestasi p ON dp.id_prestasi = p.id_prestasi
                 LEFT JOIN membimbing m ON dp.id_prestasi = m.id_prestasi
                 LEFT JOIN guru_pembimbing g ON m.id_guru = g.id_guru
                 ORDER BY dp.tanggal_prestasi DESC
                 LIMIT 10";
$result_recent = mysqli_query($koneksi, $query_recent);
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📊 Rekap Prestasi</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <div class="container mt-5">
        <h2 class="text-center mb-4">📊 Ringkasan Prestasi</h2>
        
        <!-- Ringkasan Data -->
        <div class="row mb-4">
            <!-- Jumlah Prestasi per Tingkatan -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">📊 Jumlah Prestasi per Tingkatan</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="table-blue">
                                <tr>
                                    <th>Tingkatan</th>
                                    <th>Jumlah Prestasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while ($row = mysqli_fetch_assoc($result_tingkat)) : ?>
                                    <tr>
                                        <td><?= $row['tingkatan'] ?></td>
                                        <td><?= $row['jumlah'] ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Siswa dengan Prestasi Terbanyak -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-success text-white">
                        <h5 class="mb-0">🏆 Siswa dengan Prestasi Terbanyak</h5>
                    </div>
                    <div class="card-body text-center">
                        <h4 class="text-primary"><?= $top_siswa['nama_siswa'] ?? "Belum Ada" ?></h4>
                        <p class="mb-0"><strong><?= $top_siswa['jumlah'] ?? 0 ?></strong> Prestasi</p>
                    </div>
                </div>
            </div>
        </div>

        <!-- Daftar Prestasi Terbaru -->
        <div class="card shadow-sm">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">📅 Daftar Prestasi Terbaru</h5>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered">
                    <thead class="table-blue">
                        <tr>
                            <th>👩‍🎓 Nama Siswa</th>
                            <th>🏆 Nama Prestasi</th>
                            <th>📶 Tingkatan</th>
                            <th>📅 Tanggal Perolehan</th>
                            <th>👨‍🏫 Guru Pembimbing</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result_recent)) : ?>
                            <tr>
                                <td><?= $row['nama_siswa'] ?></td>
                                <td><?= $row['nama_prestasi'] ?></td>
                                <td><?= $row['tingkatan'] ?></td>
                                <td><?= date('d-m-Y', strtotime($row['tanggal_prestasi'])) ?></td>
                                <td><?= $row['nama_guru'] ?? 'Tidak Ada' ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
