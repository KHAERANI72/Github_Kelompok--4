<?php
include "koneksi.php";
$id = $_GET['id'];
$query = mysqli_query($koneksi, "DELETE FROM guru_pembimbing WHERE id_guru='$id'");
header('Location:tbl_guru.php');

?>