<?php
$koneksi = mysqli_connect("localhost", "root", "", "skaven_rpl2") or die("Koneksi gagal!");
?>
