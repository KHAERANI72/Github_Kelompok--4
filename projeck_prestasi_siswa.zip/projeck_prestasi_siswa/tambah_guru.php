<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['tambah'])) {
    $id_guru = $_POST['id_guru'];
    $nama_guru = $_POST['nama_guru'];
    $bidang = $_POST['bidang'];
    $no_telpon = $_POST['no_telpon'];
    $email = $_POST['email'];
    $alamat = $_POST['alamat'];
    $mata_pelajaran = $_POST['mata_pelajaran'];

    $query = "INSERT INTO guru_pembimbing (id_guru, nama_guru, bidang, no_telpon, email, alamat, mata_pelajaran) 
              VALUES ('$id_guru','$nama_guru', '$bidang', '$no_telpon', '$email', '$alamat', '$mata_pelajaran')";

    if (mysqli_query($koneksi, $query)) {
        echo "Data guru berhasil ditambahkan!";
        header ('location : tbl_guru.php');
        exit();
    } else {
        echo "Gagal menambahkan data: " . mysqli_error($koneksi);
    }
}
?>
<link rel="stylesheet" href="form.css">
<div class="container">
<form method="POST" action="">
    ID Guru: <input type="text" name="id_guru" required><br>
    Nama Guru: <input type="text" name="nama_guru" required><br>
    Bidang:
    <select name="bidang">
    <option value="">-- Pilih Bidang  --</option>
        <option value="lkbb">LKBB</option>
        <option value="pemrograman">Pemrograman</option>
        <option value="matematika">Matematika</option>
        <option value="pkn">PKN</option>
    </select><br>
    No. Telepon: <input type="text" name="no_telpon" required><br>
    Email: <input type="email" name="email" required><br>
    Alamat: <textarea name="alamat" required></textarea><br>
    Mata Pelajaran: <input type="text" name="mata_pelajaran" required><br>
    <button type="submit" name="tambah">Tambah</button>
    <button type="button" onclick="window.history.back();">Kembali</button>
    <button type="reset">Batal</button>

</form>
</div>
