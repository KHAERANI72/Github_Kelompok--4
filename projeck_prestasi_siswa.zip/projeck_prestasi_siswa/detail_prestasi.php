<?php
include "koneksi.php";

if (isset($_GET['id'])) {
    $id_detail = $_GET['id'];

    $query = "SELECT dp.*, p.nama_prestasi, p.tingkat, s.nama_siswa AS nama_siswa, g.nama_guru 
              FROM detail_prestasi dp
              JOIN prestasi p ON dp.id_prestasi = p.id_prestasi
              JOIN siswaa s ON dp.id_siswa = s.id_siswa
              JOIN guru_pembimbing g ON dp.id_guru = g.id_guru
              WHERE dp.id_detailprestasi = '$id_detail'";

    $result = $koneksi->query($query);

    if ($result && $result->num_rows > 0) {
        $data = $result->fetch_assoc();
    } else {
        echo "<script>alert('Data tidak ditemukan!'); window.location='prestasi.php';</script>";
        exit; // Menghentikan eksekusi jika data tidak ditemukan
    }
} else {
    echo "<script>alert('ID tidak ditemukan!'); window.location='prestasi.php';</script>";
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detail Prestasi</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <h2> 📰 Detail Prestasi</h2>
    <table class="table table-bordered">
        <tr><th>Nama Prestasi</th><td><?= isset($data['nama_prestasi']) ? $data['nama_prestasi'] : '-'; ?></td></tr>
        <tr><th>Peringkat</th><td><?= isset($data['peringkat']) ? $data['peringkat'] : '-'; ?></td></tr>
        <tr><th>Tingkat</th><td><?= isset($data['tingkat']) ? $data['tingkat'] : '-'; ?></td></tr>
        <td><?= isset($data['tanggal_prestasi']) ? date(' d F Y', strtotime($data['tanggal_prestasi'])) : '-'; ?></td>

        <tr><th>Kategori</th><td><?= isset($data['kategori']) ? $data['kategori'] : '-'; ?></td></tr>
        <tr><th>Nama Siswa</th><td><?= isset($data['nama_siswa']) ? $data['nama_siswa'] : '-'; ?></td></tr>
        <tr><th>Guru Pembimbing</th><td><?= isset($data['nama_guru']) ? $data['nama_guru'] : '-'; ?></td></tr>
    </table>
    <a href="prestasi.php" class="btn btn-secondary">Kembali</a>
</div>

</body>
</html>
