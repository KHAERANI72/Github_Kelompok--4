<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manajemen Data Prestasi Siswa</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }
        h2 {
            text-align: center;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid black;
            text-align: center;
        }
        th, td {
            padding: 10px;
        }
        form {
            margin-top: 20px;
            padding: 10px;
            border: 1px solid #ccc;
            width: 50%;
        }
        button {
            padding: 5px 10px;
            cursor: pointer;
        }
        .edit-btn {
            background-color: #f0ad4e;
            border: none;
            color: white;
        }
        .delete-btn {
            background-color: #d9534f;
            border: none;
            color: white;
        }
    </style>
</head>
<body>

    <h2>Manajemen Data Prestasi Siswa</h2>

    <!-- Form Tambah Prestasi -->
    <form id="prestasiForm">
        <label>Nama Siswa:</label>
        <input type="text" id="nama" required><br><br>

        <label>Prestasi:</label>
        <input type="text" id="prestasi" required><br><br>

        <label>Tingkat:</label>
        <select id="tingkat">
            <option value="Sekolah">Sekolah</option>
            <option value="Kota">Kota</option>
            <option value="Provinsi">Provinsi</option>
            <option value="Nasional">Nasional</option>
            <option value="Internasional">Internasional</option>
        </select><br><br>

        <label>Tahun:</label>
        <input type="number" id="tahun" required><br><br>

        <button type="submit">Tambah Prestasi</button>
    </form>

    <!-- Tabel Daftar Prestasi -->
    <table>
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>Prestasi</th>
                <th>Tingkat</th>
                <th>Tahun</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody id="prestasiList">
            <!-- Data akan ditampilkan di sini -->
        </tbody>
    </table>

    <script>
        let prestasiData = [];
        let editIndex = -1;

        document.getElementById('prestasiForm').addEventListener('submit', function(event) {
            event.preventDefault();

            let nama = document.getElementById('nama').value;
            let prestasi = document.getElementById('prestasi').value;
            let tingkat = document.getElementById('tingkat').value;
            let tahun = document.getElementById('tahun').value;

            if (editIndex === -1) {
                // Tambah Data Baru
                prestasiData.push({ nama, prestasi, tingkat, tahun });
            } else {
                // Edit Data
                prestasiData[editIndex] = { nama, prestasi, tingkat, tahun };
                editIndex = -1;
            }

            resetForm();
            displayData();
        });

        function displayData() {
            let tbody = document.getElementById('prestasiList');
            tbody.innerHTML = "";
            prestasiData.forEach((data, index) => {
                let row = `<tr>
                    <td>${index + 1}</td>
                    <td>${data.nama}</td>
                    <td>${data.prestasi}</td>
                    <td>${data.tingkat}</td>
                    <td>${data.tahun}</td>
                    <td>
                        <button class="edit-btn" onclick="editData(${index})">Edit</button>
                        <button class="delete-btn" onclick="deleteData(${index})">Hapus</button>
                    </td>
                </tr>`;
                tbody.innerHTML += row;
            });
        }

        function editData(index) {
            document.getElementById('nama').value = prestasiData[index].nama;
            document.getElementById('prestasi').value = prestasiData[index].prestasi;
            document.getElementById('tingkat').value = prestasiData[index].tingkat;
            document.getElementById('tahun').value = prestasiData[index].tahun;
            editIndex = index;
        }

        function deleteData(index) {
            if (confirm("Yakin ingin menghapus data ini?")) {
                prestasiData.splice(index, 1);
                displayData();
            }
        }

        function resetForm() {
            document.getElementById('nama').value = "";
            document.getElementById('prestasi').value = "";
            document.getElementById('tingkat').value = "Sekolah";
            document.getElementById('tahun').value = "";
        }
    </script>

</body>
</html>
