<?php
include "koneksi.php"; // Pastikan koneksi ke database

// Ambil jumlah prestasi berdasarkan tingkat
$query_tingkat = "SELECT p.tingkat, COUNT(dp.id_prestasi) AS jumlah 
                   FROM prestasi p
                   JOIN detail_prestasi dp ON p.id_prestasi = dp.id_prestasi
                   GROUP BY p.tingkat";
$result_tingkat = mysqli_query($koneksi, $query_tingkat);


$query_top_siswa = "SELECT s.nama_siswa, COUNT(dp.id_prestasi) AS banyak_prestasi
FROM siswaa s
JOIN detail_prestasi dp ON s.id_siswa = dp.id_siswa
GROUP BY s.id_siswa
ORDER BY banyak_prestasi DESC";



$result_top_siswa = mysqli_query($koneksi, $query_top_siswa);
$top_siswa = mysqli_fetch_assoc($result_top_siswa);

// Ambil daftar prestasi terbaru dengan guru pembimbing
$query_recent = "SELECT s.nama_siswa AS nama_siswa, p.nama_prestasi, p.tingkat, dp.tanggal_prestasi, g.nama_guru 
                 FROM detail_prestasi dp
                 JOIN siswaa s ON dp.id_siswa = s.id_siswa
                 JOIN prestasi p ON dp.id_prestasi = p.id_prestasi
                 LEFT JOIN membimbing m ON dp.id_prestasi = m.id_prestasi
                 LEFT JOIN guru_pembimbing g ON m.id_guru = g.id_guru
                 ORDER BY dp.tanggal_prestasi DESC
                 LIMIT 10";
$result_recent = mysqli_query($koneksi, $query_recent);

?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>📊 Rekap Prestasi</title>
    
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Sistem Guru</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tbl_siswa.php">Data Siswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="prestasi.php">Prestasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="tbl_guru.php">Guru</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="rigkas_prestasi.php">Rekap Prestasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="logout.php">Logout</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

    <div class="container mt-5">
        <h2 class="text-center mb-4">📊 Ringkasan Prestasi</h2>
        
        <!-- Ringkasan Data -->
        <div class="row mb-4">
            <!-- Jumlah Prestasi per Tingkatan -->
            <div class="col-md-6">
                <div class="card shadow-sm">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">📊 Jumlah Prestasi per Tingkatan</h5>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered">
                            <thead class="table-blue">
                                <tr>
                                    <th>Tingkatan</th>
                                    <th>Jumlah Prestasi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php 
                                while ($row = mysqli_fetch_assoc($result_tingkat)) : ?>
                                    <tr>
                                        <td><?= $row['tingkat'] ?></td>
                                        <td><?= $row['jumlah'] ?></td>
                                    </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Siswa dengan Prestasi Terbanyak -->
            <div class="col-md-6">
    <div class="card shadow-sm">
        <div class="card-header bg-success text-white">
            <h5 class="mb-0">🏆 Siswa dengan prestasi terbaru</h5>
        </div>
        <div class="card-body">
            <table class="table table-striped table-bordered">
                <thead class="table-primary">
                    <tr>
                        <th> Nama Siswa</th>
                        <th> Jumlah Prestasi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = mysqli_fetch_assoc($result_top_siswa)) : ?>
                        <tr>
                            <td><?= $row['nama_siswa'] ?></td>
                            <td><strong><?= $row['banyak_prestasi'] ?></strong></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


        <!-- Daftar Prestasi Terbaru -->
        <div class="card shadow-sm">
            <div class="card-header bg-info text-white">
                <h5 class="mb-0">📅 Daftar Prestasi Terbaru</h5>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered">
                    <thead class="table-blue">
                        <tr>
                            <th>👩‍🎓 Nama Siswa</th>
                            <th>🏆 Nama Prestasi</th>
                            <th>📶 Tingkatan</th>
                            <th>📅 Tanggal Perolehan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($row = mysqli_fetch_assoc($result_recent)) : ?>
                            <tr>    
                                <td><?= $row['nama_siswa'] ?></td>
                                <td><?= $row['nama_prestasi'] ?></td>
                                <td><?= $row['tingkat'] ?></td>
                                <td><?= date('d-m-Y', strtotime($row['tanggal_prestasi'])) ?></td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
