<?php
include 'koneksi.php';

// Cek apakah ada ID yang dikirim lewat URL
if (isset($_GET['id'])) {
    $id_guru = intval($_GET['id']); 
    $query = "SELECT * FROM guru_pembimbing WHERE id_guru = $id_guru";
    $result = mysqli_query($koneksi, $query);
    $data = mysqli_fetch_assoc($result);
}

// Jika tombol update ditekan
if (isset($_POST['update'])) {
    $id_guru = intval($_POST['id_guru']);
    $nama_guru = mysqli_real_escape_string($koneksi, $_POST['nama_guru']);
    $bidang = mysqli_real_escape_string($koneksi, $_POST['bidang']);
    $no_telpon = mysqli_real_escape_string($koneksi, $_POST['no_telpon']);
    $email = mysqli_real_escape_string($koneksi, $_POST['email']);
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $mata_pelajaran = mysqli_real_escape_string($koneksi, $_POST['mata_pelajaran']);

    $query = "UPDATE guru_pembimbing SET 
                nama_guru='$nama_guru', bidang='$bidang', no_telpon='$no_telpon', 
                email='$email', alamat='$alamat', mata_pelajaran='$mata_pelajaran' 
              WHERE id_guru=$id_guru";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Data guru berhasil diperbarui!'); window.location='tbl_guru.php';</script>";
    } else {
        echo "Gagal memperbarui data: " . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <title>Edit Data Guru</title>
    <link rel="stylesheet" href="edit_guru.css">
</head>
<body>
    <div class="container">
        <h2>Edit Data Guru</h2>
        <form method="POST">
            <input type="hidden" name="id_guru" value="<?php echo $data['id_guru']; ?>">

            Nama Guru: <input type="text" name="nama_guru" value="<?php echo $data['nama_guru']; ?>" required>

            Bidang:
            <select name="bidang">
                <option value="lkbb" <?php if($data['bidang'] == 'lkbb') echo 'selected'; ?>>LKBB</option>
                <option value="pemrograman" <?php if($data['bidang'] == 'pemrograman') echo 'selected'; ?>>Pemrograman</option>
                <option value="matematika" <?php if($data['bidang'] == 'matematika') echo 'selected'; ?>>Matematika</option>
                <option value="pkn" <?php if($data['bidang'] == 'pkn') echo 'selected'; ?>>PKN</option>
            </select>

            No. Telepon: <input type="text" name="no_telpon" value="<?php echo $data['no_telpon']; ?>" required>

            Email: <input type="email" name="email" value="<?php echo $data['email']; ?>" required>

            Alamat: <textarea name="alamat" required><?php echo $data['alamat']; ?></textarea>

            Mata Pelajaran: <input type="text" name="mata_pelajaran" value="<?php echo $data['mata_pelajaran']; ?>" required>

            <button type="submit" name="update">Update</button>
            <button type="button" class="kembali" onclick="window.location.href='tbl_guru.php';">Kembali</button>
        </form>
    </div>
</body>
</html>
