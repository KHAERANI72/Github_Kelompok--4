<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

if (isset($_POST['submit'])) {
    $nama_prestasi = $_POST['nama_prestasi'];
    $tingkat = $_POST['tingkat'];

    // Simpan ke tabel `prestasi`
    $sql_prestasi = "INSERT INTO prestasi (nama_prestasi, tingkat) VALUES ('$nama_prestasi', '$tingkat')";
    if (mysqli_query($koneksi, $sql_prestasi)) {
        $id_prestasi = mysqli_insert_id($koneksi);
        $id_siswa = $_POST['id_siswa'];
        $id_guru = $_POST['id_guru'];
        $tanggal_prestasi = $_POST['tanggal_prestasi'];
        $peringkat = $_POST['peringkat'];
        $kategori = $_POST['kategori'];

        // Simpan ke tabel `detail_prestasi`
        $sql_detail = "INSERT IGNORE INTO detail_prestasi (id_prestasi, id_siswa, id_guru, tanggal_prestasi, peringkat, kategori) 
               VALUES ('$id_prestasi', '$id_siswa', '$id_guru', '$tanggal_prestasi', '$peringkat', '$kategori')";


        if (mysqli_query($koneksi, $sql_detail)) {
            echo "<script>alert('Data prestasi berhasil ditambahkan!'); window.location='prestasi.php';</script>";
        } else {
            echo "Gagal menambahkan detail prestasi: " . mysqli_error($koneksi);
        }
    } else {
        echo "Gagal menambahkan prestasi: " . mysqli_error($koneksi);
    }
}
?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pencatatan Prestasi Siswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<!-- Form Tambah Prestasi -->
<div class="container mt-4">
    <h2 class="text-center"> 📌 Pencatatan Prestasi Siswa</h2>
    <form method="POST" action="">
        <div class="mb-3">
            <label>Nama Prestasi</label>
            <input type="text" name="nama_prestasi" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Tingkatan</label>
            <select name="tingkat" class="form-control" required>
                <option value="">-- Pilih Tingkatan --</option>
                <?php
                $tingkat = $koneksi->query("SELECT * FROM tingkat");
                while ($row = $tingkat->fetch_assoc()) {
                    echo "<option value='{$row['tingkat']}'>{$row['tingkat']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Siswa</label>
            <select name="id_siswa" class="form-control" required>
                <option value="">-- Pilih Siswa --</option>
                <?php
                $siswa = $koneksi->query("SELECT * FROM siswaa");
                while ($row = $siswa->fetch_assoc()) {
                    echo "<option value='{$row['id_siswa']}'>{$row['nama_siswa']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Guru Pembimbing</label>
            <select name="id_guru" class="form-control" required>
                <option value="">-- Pilih Guru --</option>
                <?php
                $guru = $koneksi->query("SELECT * FROM guru_pembimbing");
                while ($row = $guru->fetch_assoc()) {
                    echo "<option value='{$row['id_guru']}'>{$row['nama_guru']}</option>";
                }
                ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Tanggal Prestasi</label>
            <input type="date" name="tanggal_prestasi" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Peringkat</label>
            <input type="number" name="peringkat" class="form-control" min="1" max="3" required>

        </div>

        <div class="mb-3">
            <label>Kategori</label>
            <select name="kategori" class="form-control">
                <option value="umum">Umum</option>
                <option value="produktif">Produktif</option>
            </select>
        </div>

        <button type="submit" name="submit" class="btn btn-primary">Tambah Prestasi</button>
        <button type="button" onclick="window.history.back();" class="btn btn-primary">Kembali</button>
        <button type="reset" class="btn btn-primary">Batal</button>
    </form>
</div>