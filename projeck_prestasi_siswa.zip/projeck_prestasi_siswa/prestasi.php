<?php
session_start();
include "koneksi.php";

if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

?>


<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pencatatan Prestasi Siswa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>

<!-- Navbar -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
        <a class="navbar-brand" href="#">Sistem Prestasi</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" href="index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tbl_siswa.php">Data Siswa</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link active" href="prestasi.php">Prestasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tbl_guru.php">Guru</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="rigkas_prestasi.php">Rekap Prestasi</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link " href="logout.php">Logout</a>
                </li>   
            </ul>
        </div>
    </div>
</nav>


<!-- Daftar Prestasi yang Sudah Dicatat -->
<div class="container mt-4">
    <h3 class="text-center"> 📰 Data Prestasi Siswa</h3>
    <a href="tambah_prestasi.php" class="btn btn-primary mb-3">✅ Tambah Data</a> <br>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>No</th>
            <th>Nama Prestasi</th>
            <th>Juara</th>
            <th>Tingkatan</th>
            <th>Tahun</th>
            <th>Aksi</th>
        </tr>
        </thead>
        <tbody>
            <?php
            $no = 1;
            error_reporting(E_ALL);
         ini_set('display_errors', 3);

            $query = "SELECT dp.id_detailprestasi, p.nama_prestasi, dp.peringkat AS juara, p.tingkat, YEAR(dp.tanggal_prestasi) AS tahun 
          FROM detail_prestasi dp
          JOIN prestasi p ON dp.id_prestasi = p.id_prestasi";

            $result = $koneksi->query($query);

            echo "Jumlah data: " . $result->num_rows . "<br>";


            while ($row = $result->fetch_assoc()) {
                

                echo "<tr>
                <td>{$no}</td>
                <td>{$row['nama_prestasi']}</td>
                <td>Juara {$row['juara']}</td>
                <td>{$row['tingkat']}</td>
                <td>{$row['tahun']}</td>
                <td><a href='detail_prestasi.php?id={$row['id_detailprestasi']}' class='btn btn-info btn-sm'>Detail</a></td>
              </tr>";
               $no++;

            }
            ?>
        </tbody>
    </table>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
