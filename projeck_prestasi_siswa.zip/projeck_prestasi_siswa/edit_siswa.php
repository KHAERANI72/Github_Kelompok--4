<?php
include 'koneksi.php';

// Pastikan id yang diterima valid
if (isset($_GET['id'])) {
    $id = mysqli_real_escape_string($koneksi, $_GET['id']);
    $query = "SELECT * FROM siswaa WHERE id_siswa = '$id'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) > 0) {
        $data = mysqli_fetch_assoc($result);
    } else {
        die("Data tidak ditemukan!");
    }
}

// Proses update
if (isset($_POST['update'])) {
    $nama_siswa = mysqli_real_escape_string($koneksi, $_POST['nama_siswa']);
    $kelas = mysqli_real_escape_string($koneksi, $_POST['kelas']);
    $jurusan = mysqli_real_escape_string($koneksi, $_POST['jurusan']);
    $jenis_kelamin = mysqli_real_escape_string($koneksi, $_POST['jenis_kelamin']);
    $saldo = (int) str_replace(['Rp', '.', ' '], '', $_POST['saldo']); 
    $alamat = mysqli_real_escape_string($koneksi, $_POST['alamat']);
    $keahlian = mysqli_real_escape_string($koneksi, $_POST['keahlian']);

    $query = "UPDATE siswaa SET 
                nama_siswa='$nama_siswa', 
                kelas='$kelas', 
                jurusan='$jurusan', 
                jenis_kelamin='$jenis_kelamin', 
                saldo='$saldo', 
                alamat='$alamat', 
                keahlian='$keahlian' 
              WHERE id_siswa='$id'";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>alert('Data berhasil diperbarui!'); window.location='tbl_siswa.php';</script>";
    } else {
        echo "<script>alert('Gagal memperbarui data: " . mysqli_error($koneksi) . "'); </script>";
    }
}
?>

<link rel="stylesheet" href="form.css">
<div class="container">
<form method="POST" action="edit_siswa.php?id=<?php echo $id; ?>">
    <label>Id:</label>
    <input type="text" name="id_siswa" value="<?php echo htmlspecialchars($data['id_siswa']); ?>" readonly><br>

    <label>Nama:</label>
    <input type="text" name="nama_siswa" value="<?php echo htmlspecialchars($data['nama_siswa']); ?>" required><br>

    <label>Kelas:</label>
    <input type="text" name="kelas" value="<?php echo htmlspecialchars($data['kelas']); ?>" required><br>

    <label>Jurusan:</label>
    <input type="text" name="jurusan" value="<?php echo htmlspecialchars($data['jurusan']); ?>" required><br>

    <label>Jenis Kelamin:</label>
    <select name="jenis_kelamin">
        <option value="Laki-laki" <?php if($data['jenis_kelamin'] == 'Laki-laki') echo 'selected'; ?>>Laki-laki</option>
        <option value="Perempuan" <?php if($data['jenis_kelamin'] == 'Perempuan') echo 'selected'; ?>>Perempuan</option>
    </select><br>

    <label>Saldo:</label>
    <input type="text" name="saldo" id="saldo" value="<?php echo 'Rp ' . number_format($data['saldo'], 0, ',', '.'); ?>" required><br>

    <label>Alamat:</label>
    <input type="text" name="alamat" value="<?php echo htmlspecialchars($data['alamat']); ?>" required><br>

    <label>Keahlian:</label>
    <input type="text" name="keahlian" value="<?php echo htmlspecialchars($data['keahlian']); ?>" required><br>

    <button type="submit" name="update">Update</button>
    <button type="button" onclick="window.history.back();">Kembali</button>
    <button type="reset">Batal</button>
</form>
</div>

<script>
// Format input saldo agar selalu menampilkan "Rp" dan titik sebagai pemisah ribuan
document.getElementById('saldo').addEventListener('input', function (e) {
    let angka = this.value.replace(/[^\d]/g, ''); // Hanya angka
    this.value = angka ? 'Rp ' + new Intl.NumberFormat('id-ID').format(angka) : '';
});
</script>
